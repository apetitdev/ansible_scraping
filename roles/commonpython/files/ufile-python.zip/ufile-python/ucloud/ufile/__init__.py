# -*- coding: utf-8 -*-

"""
UCloud UFile SDK for python
"""

__version__ = '2.0.0'
